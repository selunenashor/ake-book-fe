import './bootstrap';
import 'bootstrap';
import.meta.glob([
    '../img/**',
  ]);
